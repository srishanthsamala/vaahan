package com.vahaan;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;
    private boolean isConnected = false;
    private static final int REQUEST_ENABLE_BT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView forwardButton = findViewById(R.id.forwardButton);
        ImageView backwardButton = findViewById(R.id.backwardButton);
        ImageView leftButton = findViewById(R.id.leftButton);
        ImageView rightButton = findViewById(R.id.rightButton);
        Button stopButton = findViewById(R.id.stopButton);

        ImageView imageView = (ImageView) findViewById(R.id.forwardButton);
        imageView.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    //Image Pressed
                    sendCommand("F");
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    //finger was lifted
                    sendCommand("S");
                }
                
                return false;
            }
        });

        /*

        forwardButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    //Button Pressed
                    sendCommand("F");
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    //finger was lifted
                    sendCommand("S");
                }
                return false;
            }
        });

         */

        backwardButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    //Button Pressed
                    sendCommand("B");
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    //finger was lifted
                    sendCommand("S");
                }
                return false;
            }
        });

        leftButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    //Button Pressed
                    sendCommand("L");
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    //finger was lifted
                    sendCommand("S");
                }
                return false;
            }
        });

        rightButton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    //Button Pressed
                    sendCommand("R");
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    //finger was lifted
                    sendCommand("S");
                }
                return false;
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCommand("S");
            }
        });

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {
            showToast("Bluetooth is not supported on this device");
            finish();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            // Bluetooth is not enabled, request to enable it
            requestBluetoothEnable();
        }

        connectBluetooth();
    }

    private void requestBluetoothEnable() {
        // Check if the necessary permission is granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            // Request the Bluetooth permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_ENABLE_BT);
        } else {
            // Bluetooth permission is granted, request to enable Bluetooth
            enableBluetooth();
        }
    }

    private void enableBluetooth() {
        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_ENABLE_BT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Bluetooth permission granted, request to enable Bluetooth
                enableBluetooth();
            } else {
                showToast("Bluetooth permission denied. The app may not work properly.");
            }
        }
    }

    private void connectBluetooth() {
        if (isConnected) {
            return;
        }

        String deviceAddress = "00:22:12:02:1F:AE"; //string bluetooth address
        BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);

        UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

        try {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling ActivityCompat#requestPermissions
                return;
            }
            bluetoothSocket = device.createRfcommSocketToServiceRecord(uuid);
            bluetoothSocket.connect();
            outputStream = bluetoothSocket.getOutputStream();
            isConnected = true;
            showToast("Connected to " + deviceAddress);
        } catch (IOException e) {
            showToast("Failed to connect to " + deviceAddress);
            e.printStackTrace();
        }
    }

    private void sendCommand(String command) {
        if (!isConnected) {
            showToast("Not connected to the Bluetooth device");
            return;
        }

        try {
            outputStream.write(command.getBytes());
            showToast("sent done");
        } catch (IOException e) {
            showToast("Failed to send command");
            e.printStackTrace();
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (outputStream != null) {
                outputStream.close();
            }
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
            }
        } catch (IOException e) {
            showToast("Failed to close Bluetooth socket");
            e.printStackTrace();
        }
    }
}

